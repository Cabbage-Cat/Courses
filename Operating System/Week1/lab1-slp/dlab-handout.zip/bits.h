
int bitAnd(int, int);
int test_bitAnd(int, int);






int bitOr(int, int);
int test_bitOr(int, int);






int isZero(int);
int test_isZero(int);






int minusOne();
int test_minusOne();






int tmax();
int test_tmax();







int bitXor(int, int);
int test_bitXor(int, int);






int getByte(int, int);
int test_getByte(int, int);






int isEqual(int, int);
int test_isEqual(int, int);






int negate(int);
int test_negate(int);






int isPositive(int);
int test_isPositive(int);





